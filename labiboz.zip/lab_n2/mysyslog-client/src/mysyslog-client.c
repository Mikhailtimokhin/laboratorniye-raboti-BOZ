#include "/home/kibler/Desktop/SOS-Labs/lab_n2/libmysyslog/include/libmysyslog.h"

int main() {
    mysyslog("Hello from client!");
    return 0;
}

