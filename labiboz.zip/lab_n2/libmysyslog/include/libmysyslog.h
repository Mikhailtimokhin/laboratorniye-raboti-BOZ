#ifndef LIBMYSYSLOG_H
#define LIBMYSYSLOG_H

void mysyslog(const char *message);

#endif
